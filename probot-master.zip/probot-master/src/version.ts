// The version is set automatically before publish to npm
export const VERSION = "0.0.0-development";
