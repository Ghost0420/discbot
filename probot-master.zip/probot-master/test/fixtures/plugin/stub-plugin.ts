// tslint:disable-next-line:no-empty
export = () => {};
